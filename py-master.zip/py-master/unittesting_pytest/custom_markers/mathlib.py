def calc_total(a,b):
    return a+b

def calc_multiply(a,b):
    return a*b







